from gturtle import *

makeTurtle()
hideTurtle()

def square():
    repeat 4:
        forward(100)
        right(90)
        
repeat 4:
    square()
    right(90)
