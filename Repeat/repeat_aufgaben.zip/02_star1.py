from gturtle import *

makeTurtle()

hideTurtle()

right(18)

repeat 5:
    forward(100)
    right(180-36)
    forward(100)
    left(72)

