from gturtle import *

makeTurtle()
hideTurtle()

repeat 6:
    forward(80)
    left(30)
    repeat 3:
        forward(20)
        left(120)
    right(90)
